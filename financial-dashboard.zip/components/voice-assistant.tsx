"use client"

import { useState } from "react"
import { Mic, MicOff, Volume2, MessageSquare } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export function VoiceAssistant() {
  const [isListening, setIsListening] = useState(false)
  const [lastCommand, setLastCommand] = useState("")
  const [response, setResponse] = useState("")

  const toggleListening = () => {
    setIsListening(!isListening)
    if (!isListening) {
      // Simulate voice recognition
      setTimeout(() => {
        const commands = [
          "Show last month expenses",
          "Check for fraud alerts",
          "What is my credit score",
          "Generate budget report",
        ]
        const command = commands[Math.floor(Math.random() * commands.length)]
        setLastCommand(command)
        setResponse(getVoiceResponse(command))
        setIsListening(false)
      }, 3000)
    }
  }

  const getVoiceResponse = (command: string) => {
    const responses = {
      "Show last month expenses":
        "Your total expenses last month were $3,200. Housing was your largest expense at $1,200.",
      "Check for fraud alerts": "I found 3 suspicious transactions. Account #4521 has high-risk activity.",
      "What is my credit score":
        "Your current credit score is 742, which is considered good. It increased by 15 points this month.",
      "Generate budget report": "Your budget analysis shows you're saving 25% of your income. Great job!",
    }
    return responses[command] || "I'm processing your request. Please wait a moment."
  }

  return (
    <Card className="bg-white/70 backdrop-blur-sm border border-slate-200/50 shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center space-x-3">
          <div className="p-2 bg-indigo-100 rounded-lg">
            <Volume2 className="w-5 h-5 text-indigo-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-slate-800">Voice Assistant</h3>
            <p className="text-sm text-slate-500">AI-powered financial queries</p>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="text-center">
        <div className="mb-6">
          <Button
            onClick={toggleListening}
            className={`w-20 h-20 rounded-full ${
              isListening
                ? "bg-red-500 hover:bg-red-600 animate-pulse"
                : "bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600"
            } shadow-lg`}
          >
            {isListening ? <MicOff className="w-8 h-8 text-white" /> : <Mic className="w-8 h-8 text-white" />}
          </Button>
        </div>

        <div className="space-y-4">
          {isListening && (
            <div className="flex items-center justify-center space-x-2 text-blue-600">
              <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" />
              <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: "0.1s" }} />
              <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }} />
              <span className="ml-2 text-sm font-medium">Listening...</span>
            </div>
          )}

          {lastCommand && (
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <div className="text-xs text-slate-500 mb-1 flex items-center">
                <MessageSquare className="w-3 h-3 mr-1" />
                You said:
              </div>
              <div className="text-blue-600 font-medium">"{lastCommand}"</div>
            </div>
          )}

          {response && (
            <div className="bg-blue-50 p-3 rounded-xl border border-blue-200">
              <div className="text-xs text-slate-500 mb-1 flex items-center">
                <Volume2 className="w-3 h-3 mr-1" />
                Assistant:
              </div>
              <div className="text-slate-700">{response}</div>
            </div>
          )}
        </div>

        <div className="mt-6 text-xs text-slate-500 bg-slate-50 p-3 rounded-lg">
          <div className="font-medium mb-1">Try saying:</div>
          <div>"Check for fraud" • "Show my credit score" • "Generate budget report"</div>
        </div>
      </CardContent>
    </Card>
  )
}
